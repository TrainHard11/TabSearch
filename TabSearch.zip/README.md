
# TabSearch


## Chrome:
1. Activate DEV mode
2. From "Extentions" : "Load Unpacked"


## Mozzila:


#### Testing
about:debugging#addons

1. Load Temporary Add-on..
2. Select the "manifest.json"
